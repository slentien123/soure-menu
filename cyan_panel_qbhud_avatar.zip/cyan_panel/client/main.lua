local open = false
local currentSettings = {}
function applySettings(settings)
    currentSettings = settings or {}
    TriggerEvent('cyan_panel:settingsChanged', currentSettings)
    if currentSettings.freezeTime then NetworkOverrideClockTime(currentSettings.time or 12, 0, 0)
    else NetworkClearClockTimeOverride() end
end

local function notify(msg, typ)
    SendNUIMessage({ action = 'toast', message = msg, type = typ or 'info' })
end

RegisterCommand(Config.Command, function()
    if open then return end
    TriggerServerEvent('cyan_panel:server:open')
end, false)

RegisterKeyMapping(Config.Command, 'Open Cyan Panel', 'keyboard', Config.Key)

RegisterNetEvent('cyan_panel:client:openData', function(data)
    applySettings(data.settings)
    open = true
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = 'open', data = data })
end)

RegisterNetEvent('cyan_panel:client:refreshData', function(data)
    SendNUIMessage({ action = 'refresh', data = data })
end)

RegisterNetEvent('cyan_panel:client:toast', function(msg, typ)
    notify(msg, typ)
end)

RegisterNetEvent('cyan_panel:client:settings', function(settings)
    applySettings(settings)
    SendNUIMessage({ action = 'settings', settings = settings })
end)

RegisterNetEvent('cyan_panel:client:parties', function(parties)
    SendNUIMessage({ action = 'parties', parties = parties })
end)

RegisterNUICallback('close', function(_, cb)
    open = false
    SetNuiFocus(false, false)
    cb({ ok = true })
end)

RegisterNUICallback('joinEvent', function(data, cb)
    TriggerServerEvent('cyan_panel:server:joinEvent', data.id)
    cb({ ok = true })
end)

RegisterNUICallback('saveSetting', function(data, cb)
    TriggerServerEvent('cyan_panel:server:saveSetting', data.key, data.value)
    cb({ ok = true })
end)

RegisterNUICallback('createParty', function(data, cb)
    TriggerServerEvent('cyan_panel:server:createParty', data.name, data.private == true)
    cb({ ok = true })
end)

RegisterNUICallback('joinParty', function(data, cb)
    TriggerServerEvent('cyan_panel:server:joinParty', data.id, data.invite)
    cb({ ok = true })
end)

RegisterNUICallback('leaveParty', function(_, cb)
    TriggerServerEvent('cyan_panel:server:leaveParty')
    cb({ ok = true })
end)

RegisterNUICallback('redeem', function(data, cb)
    TriggerServerEvent('cyan_panel:server:redeem', data.code)
    cb({ ok = true })
end)

RegisterNUICallback('adminCreateCode', function(data, cb)
    TriggerServerEvent('cyan_panel:server:adminCreateCode', data.code, data.rewards, data.maxUses, data.hours)
    cb({ ok = true })
end)

RegisterNUICallback('adminDeleteCode', function(data, cb)
    TriggerServerEvent('cyan_panel:server:adminDeleteCode', data.code)
    cb({ ok = true })
end)

RegisterNUICallback('adminToggleCode', function(data, cb)
    TriggerServerEvent('cyan_panel:server:adminToggleCode', data.code, data.enabled == true)
    cb({ ok = true })
end)

RegisterNUICallback('adminListCodes', function(_, cb)
    TriggerServerEvent('cyan_panel:server:adminListCodes')
    cb({ ok = true })
end)

RegisterNUICallback('refresh', function(_, cb)
    TriggerServerEvent('cyan_panel:server:refresh')
    cb({ ok = true })
end)

CreateThread(function()
    while true do
        if open then
            DisableControlAction(0, 1, true)
            DisableControlAction(0, 2, true)
            DisableControlAction(0, 200, true)
        end
        Wait(0)
    end
end)

RegisterNetEvent('cyan_panel:client:open', function()
    if not open then TriggerServerEvent('cyan_panel:server:open') end
end)

RegisterNetEvent('cyan_panel:client:giftCodes', function(codes)
    SendNUIMessage({action = 'giftCodes', codes = codes})
end)
RegisterNetEvent('cyan_panel:client:sync', function(data)
    SendNUIMessage({action = 'sync', data = data})
end)
RegisterNUICallback('submitPin', function(data, cb) TriggerServerEvent('cyan_panel:server:submitPin', data.pin); cb({ok=true}) end)
RegisterNUICallback('readMail', function(_, cb) TriggerServerEvent('cyan_panel:server:readMail'); cb({ok=true}) end)
CreateThread(function()
    Wait(1000)
    TriggerServerEvent('cyan_panel:server:sync')
    while true do
        if currentSettings.freezeTime then NetworkOverrideClockTime(currentSettings.time or 12, 0, 0) end
        Wait(1000)
    end
end)
AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    NetworkClearClockTimeOverride()
end)

RegisterNetEvent('cyan_panel:client:avatar', function(url)
    if open then SendNUIMessage({action = 'avatar', url = url}) end
end)
RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    open = false
    SetNuiFocus(false, false)
    SendNUIMessage({action = 'characterUnload'})
end)
CreateThread(function()
    while true do
        Wait(math.max(3, Config.HudAvatar.RefreshSeconds or 5) * 1000)
        if open and Config.HudAvatar.Enabled then TriggerServerEvent('cyan_panel:server:avatar') end
    end
end)
