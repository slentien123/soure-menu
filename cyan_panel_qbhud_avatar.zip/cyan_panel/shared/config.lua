Config = {}

-- auto | qb | esx
Config.Framework = 'auto'
Config.Command = 'cyanpanel'
Config.Key = 'F10'
Config.Debug = false
Config.Locale = 'en'

-- Framework resources. Change these only if your server uses renamed resources.
Config.Resources = {
    QBCore = 'qb-core',
    ESX = 'es_extended'
}

Config.Admin = {
    Ace = 'cyanpanel.admin',
    FrameworkGroups = { 'god', 'admin', 'superadmin' }
}


Config.DefaultAvatar = 'assets/avatar.svg'

-- Event hooks. Replace these with your server's actual event names.
-- The resource itself tracks membership locally and sends these hooks when configured.
Config.Events = {
    AirdropJoin = '',       -- client event, e.g. 'my_airdrop:client:join'
    TeamDeathmatchJoin = '',
    PropHuntJoin = '',
    PartyCreate = '',
    PartyJoin = '',
    PartyLeave = ''
}

-- Event cards shown at the top / home page.
Config.EventCards = {
    {
        id = 'airdrop', title = 'AIRDROP ALL', label = 'AIRDROP',
        subtitle = 'DROP EVENT', icon = '◇', maxPlayers = 88,
        image = '', joinEvent = 'AirdropJoin'
    },
    {
        id = 'tdm', title = 'TEAM DEATHMATCH', label = 'TEAM DEATHMATCH',
        subtitle = 'TEAM BATTLE', icon = 'VS', maxPlayers = 88,
        image = '', joinEvent = 'TeamDeathmatchJoin'
    },
    {
        id = 'prop', title = 'PROP HUNT', label = 'PROP HUNT',
        subtitle = 'HIDE & SEEK', icon = '◎', maxPlayers = 88,
        image = '', joinEvent = 'PropHuntJoin'
    }
}

Config.Settings = {
    navigation = true,
    autoEquip = false,
    musicBox = true,
    reroll = true,
    bodybag = true,
    item3D = true,
    timeItem = false,
    customSound = true,
    hitVolume = 0.65,
    skinKillSound = true,
    skinKillEffect = true,
    freezeTime = false,
    time = 12
}

Config.Party = {
    MaxMembers = 5,
    MaxPartiesShown = 9
}

Config.Referral = {
    RewardEvery = 50,
    Rewards = {
        { type = 'item', name = 'water', amount = 2 }
    }
}

-- Gift code persistence uses a JSON file inside this resource, no SQL dependency.
Config.GiftCodeFile = 'data/codes.json'
Config.GiftCodeMaxUses = 400

-- Server-side reward types: item, money, weapon.
-- Examples are in README.md.

-- Local server event handlers in your game resources (not network events).
Config.ServerJoinEvents = { airdrop = '', tdm = '', prop = '' }
-- Show only integrated settings. Add keys when a resource handles cyan_panel:settingsChanged.
Config.AvailableSettings = { navigation = true, musicBox = true, hitVolume = true, freezeTime = true, time = true }

-- Use the same per-character avatar database as the supplied qb-hud.
Config.HudAvatar = { Enabled = true, Resource = 'qb-hud', DatabaseResource = 'oxmysql', RefreshSeconds = 5 }
