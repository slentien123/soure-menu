fx_version 'cerulean'
game 'gta5'

lua54 'yes'

name 'cyan_panel'
author 'OpenAI'
description 'Cyan event / profile / party / redeem panel for FiveM - QB-Core + ESX'
version '2.0.1'

ui_page 'html/index.html'

shared_scripts {
    'shared/config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/secret.lua',
    'server/main.lua'
}

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/assets/avatar.svg'
}
