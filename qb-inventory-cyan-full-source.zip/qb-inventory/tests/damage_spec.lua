local handlers,modifiers,sent={},{},{}
local weapon={slot=1,name='weapon_pistol',type='weapon',info={level=3,quality=90,serie='TEST'}}
local core={Functions={GetPlayer=function()return {PlayerData={items={[1]=weapon}}}end}}
exports={['qb-core']={GetCoreObject=function()return core end}}
RegisterNetEvent=function(name,fn)handlers[name]=fn end
AddEventHandler=RegisterNetEvent
RegisterNUICallback=function()end
CreateThread=function()end
joaat=function(name)return name=='weapon_pistol' and 100 or name=='weapon_bat' and 200 or 300 end
GetWeaponDamage=function()return 25 end
SetWeaponDamageModifier=function(hash,modifier)modifiers[hash]=modifier end
GetResourceState=function()return 'missing'end
CyanTrade={isBusy=function()return false end}
dofile('shared/cyan.lua');dofile('client/cyan.lua')
handlers['cyan:weaponEquipped'](weapon)
assert(math.abs(modifiers[100]-31/25)<0.000001)
handlers['cyan:weaponEquipped']({name='weapon_bat',info={level=6}})
assert(modifiers[100]==1);assert(math.abs(modifiers[200]-.22)<0.000001)
handlers['cyan:weaponEquipped'](nil);assert(modifiers[200]==1)
assert(CyanLevel({level=999})==6 and CyanLevel({lever=4})==4)
print('PASS damage: gun level 3 +6, melee level 6 nominal +12, reset, legacy lever, clamp')
dofile('server/damage.lua')
GetPlayerPed=function(src)return src end
NetworkGetEntityFromNetworkId=function(id)return id end
DoesEntityExist=function()return true end
GetEntityType=function()return 1 end
NetworkGetEntityOwner=function()return 2 end
GetPlayerRoutingBucket=function()return 0 end
GetGameTimer=function()return 1000 end
GetEntityCoords=function()return setmetatable({},{__sub=function()return setmetatable({},{__len=function()return 1 end})end})end
TriggerClientEvent=function(name,owner,...)sent[#sent+1]={name,owner,...}end
math.random=function()return .29 end
CyanDamageEquip(1,weapon)
local hit={weaponType=100,hitGlobalId=2,damageTime=500}
handlers.weaponDamageEvent(1,hit);assert(#sent==2)
handlers.weaponDamageEvent(1,hit);assert(#sent==2)
math.random=function()return .31 end
handlers.weaponDamageEvent(1,{weaponType=100,hitGlobalId=2,damageTime=501});assert(#sent==2)
weapon.info.serie='OTHER';math.random=function()return 0 end
handlers.weaponDamageEvent(1,{weaponType=100,hitGlobalId=2,damageTime=502});assert(#sent==2)
print('PASS critical: 30% at level 3, duplicate hit suppression, serial mismatch rejected')
