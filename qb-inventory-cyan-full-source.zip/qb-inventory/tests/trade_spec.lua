-- Run from qb-inventory root with Lua 5.4: lua tests/trade_spec.lua
local handlers,messages,players,states,commands={},{},{},{},{}
local clock=1000;os.time=function() return clock end
local position={[1]=0,[2]=1,[3]=2}
local vec={__sub=function(a,b)return setmetatable({x=a.x-b.x},{__len=function(v)return math.abs(v.x)end})end}
GetEntityCoords=function(id)return setmetatable({x=position[id] or 0},vec)end
GetPlayerPed=function(id)return players[id] and id or 0 end
GetPlayerRoutingBucket=function()return 0 end
GetEntityHealth=function()return 200 end
GetPlayerName=function(id)return players[id] and 'Player '..id end
GetCurrentResourceName=function()return 'qb-inventory'end
Player=function(id)states[id]=states[id] or {set=function(self,k,v)self[k]=v end};return {state=states[id]}end
TriggerClientEvent=function(event,src,data)messages[event]=messages[event] or {};messages[event][src]=data end
TriggerEvent=function()end
RegisterNetEvent=function(event,fn)handlers[event]=fn end
AddEventHandler=RegisterNetEvent
CreateThread=function()end
local writes=0
MySQL={transaction=function(queries,cb)writes=writes+1;assert(#queries==2);cb(true)end}
json={encode=function()return '{}'end}
local core={Functions={GetPlayer=function(id)return players[id]end},Commands={Add=function(name,_,_,_,fn,perm)commands[name]={fn=fn,permission=perm}end}}
exports=setmetatable({['qb-core']={GetCoreObject=function()return core end}},{__call=function()end})
Config={MaxInventorySlots=12,MaxInventoryWeight=10000}
dofile('shared/cyan.lua')
dofile('server/trade.lua')
local function item(name,slot,amount,level,weight)
 return {name=name,label=name,slot=slot,amount=amount,weight=weight or 100,type='item',unique=false,image=name..'.png',info={level=level,serial='serial-'..slot}}
end
local function reset()
 for id=1,3 do
  if CyanTrade.isBusy(id)then source=id;handlers['cyan:tradeCancel'](messages['cyan:tradeState'][id].id)end
  players[id]={PlayerData={citizenid='C'..id,charinfo={firstname='P'..id},metadata={},items={}},Functions={}}
  local p=players[id];p.Functions.SetPlayerData=function(k,v)p.PlayerData[k]=v end
 end
 position[2]=1;clock=clock+10
end
local function call(id,event,... )source=id;handlers['cyan:'..event](...)end
local function start()
 call(1,'tradeRequest',2);call(2,'tradeAnswer',1,true)
 assert(CyanTrade.isBusy(1) and CyanTrade.isBusy(2));return messages['cyan:tradeState'][1].id
end
local function rev()return messages['cyan:tradeState'][1].revision end
local function lock(id)
 call(1,'tradeLock',id,rev());call(2,'tradeLock',id,rev())
end
local function confirm(id)
 call(1,'tradeConfirm',id,rev());call(2,'tradeConfirm',id,rev())
end
reset();players[1].PlayerData.items[1]=item('water',1,5,2);players[2].PlayerData.items[2]=item('radio',2,1,5)
local id=start();call(1,'tradeOffer',id,1,2);call(2,'tradeOffer',id,2,1)
call(1,'tradeConfirm',id,rev());assert(players[1].PlayerData.items[1].amount==5)
lock(id);call(1,'tradeConfirm',id,rev());assert(CyanTrade.isBusy(1));call(2,'tradeConfirm',id,rev())
assert(not CyanTrade.isBusy(1));assert(players[1].PlayerData.items[1].amount==3);assert(players[1].PlayerData.items[2].name=='radio');assert(players[1].PlayerData.items[2].info.level==5)
assert(players[2].PlayerData.items[1].amount==2);assert(writes==1)
call(2,'tradeConfirm',id,1);assert(writes==1)
print('PASS two locks, two confirmations, partial stack, metadata, replay')
reset();players[1].PlayerData.items[1]=item('water',1,5,1);id=start()
call(1,'tradeOffer',id,1,-2);assert(#messages['cyan:tradeState'][1].mine==0)
call(1,'tradeOffer',id,1,1.5);assert(#messages['cyan:tradeState'][1].mine==0)
call(1,'tradeOffer',id,1,6);assert(#messages['cyan:tradeState'][1].mine==0)
call(1,'tradeOffer',id,1,1);lock(id);local stale=rev();call(1,'tradeLock',id,stale)
call(1,'tradeOffer',id,1,2);assert(not messages['cyan:tradeState'][1].otherLocked)
call(2,'tradeConfirm',id,stale);assert(CyanTrade.isBusy(1));assert(writes==1)
call(3,'tradeOffer',id,1,1);assert(#messages['cyan:tradeState'][1].mine==1)
print('PASS invalid quantities, stale revision, changed offer resets both, outsider')
position[2]=100;call(1,'tradeLock',id,rev());assert(not CyanTrade.isBusy(1))
print('PASS distance cancellation')
reset();players[1].PlayerData.items[1]=item('heavy',1,1,1,20000);id=start();call(1,'tradeOffer',id,1,1);lock(id);confirm(id)
assert(players[1].PlayerData.items[1].name=='heavy');assert(writes==1);assert(not messages['cyan:tradeState'][1].locked)
print('PASS weight preflight leaves both inventories unchanged')
reset();players[1].PlayerData.items[1]=item('water',1,1,1);id=start();call(1,'tradeOffer',id,1,1);lock(id)
players[1].PlayerData.items[1].info.level=6;confirm(id);assert(not CyanTrade.isBusy(1));assert(writes==1)
print('PASS metadata tampering cancels transaction')
reset();id=start();source=2;handlers.playerDropped();assert(not CyanTrade.isBusy(1))
assert(commands.testtrade.permission=='admin');print('PASS disconnect cleanup and admin-only preview registration')
reset();id=start();assert(CyanTrade.beforeMutation(1));assert(not CyanTrade.isBusy(2));print('PASS external inventory mutation cancels reservation')
print('ALL TRADE TESTS PASSED')
