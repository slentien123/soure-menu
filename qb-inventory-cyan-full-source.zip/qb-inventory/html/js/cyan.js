(() => {
  const $trade=()=>document.getElementById('cyan-trade'),$invite=()=>document.getElementById('cyan-invite');
  const colors=['#64748b','#00e676','#2d9cff','#d000ff','#ff6600','#ff0033'];
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let trade=null,invite=null,quantity=1,clock=0,toastTimer;
  const post=(action,data={})=>fetch(`https://${typeof GetParentResourceName==='function'?GetParentResourceName():'qb-inventory'}/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).catch(()=>toast('Không kết nối được với game.'));
  function toast(message){if(!message)return;const e=document.getElementById('cyan-toast');e.textContent=message;e.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.hidden=true,3500)}
  const list=items=>Object.values(items||{}).filter(Boolean).sort((a,b)=>Number(a.slot)-Number(b.slot));
  function itemHtml(item,context,offered=false){
    if(!item)return '<div class="ct-item ct-empty"></div>';
    const level=QbiGetItemLevel(item),image=String(item.image||'').replace(/[^a-zA-Z0-9_.-]/g,'');
    return `<button class="ct-item ${offered?'offered':''}" style="--rarity:${colors[level-1]}" data-trade-slot="${Number(item.slot)}" data-context="${context}" ${context==='theirs'?'disabled':''} title="${esc(item.label)} · LEVEL ${level} · x${Number(item.amount)}"><span class="ct-weight">${((Number(item.weight)||0)*Number(item.amount)/1000).toFixed(2)} kg</span><span class="ct-level">L${level}</span><img src="images/${image}" alt=""><span class="ct-label">${esc(item.label)}</span><span class="ct-count">${Number(item.amount)}</span></button>`;
  }
  function offerGrid(items,context){return Array.from({length:trade.maxOffers||5},(_,i)=>itemHtml(items[i],context)).join('')}
  function render(){
    if(!trade)return;
    const bag=list(trade.inventory),weight=bag.reduce((s,i)=>s+(Number(i.weight)||0)*i.amount,0)/1000;
    const empty=Math.max(0,20-bag.length),seconds=Math.max(0,Math.ceil(trade.seconds-(performance.now()-clock)/1000));
    $trade().innerHTML=`<div class="ct-shell"><div class="ct-top"><div class="ct-brand">CYAN EXCHANGE<small>GIAO DỊCH VẬT PHẨM</small></div><div class="ct-top-right">${trade.demo?'<span class="ct-demo">ADMIN PREVIEW · KHÔNG CHUYỂN ĐỒ</span>':'<span>PHIÊN #'+esc(trade.id)+'</span>'}<span id="ct-timer">${seconds}s</span><button class="ct-close" data-action="cancel" aria-label="Đóng">×</button></div></div><div class="ct-body"><div class="ct-bag"><div class="ct-bag-head"><h2>TÚI ĐỒ CÁ NHÂN</h2><span>${weight.toFixed(2)} / ${(trade.maxWeight/1000).toFixed(0)} kg</span></div><div class="ct-bag-grid">${bag.map(i=>itemHtml(i,'bag',trade.mine.some(x=>x.slot===i.slot))).join('')}${Array.from({length:empty},()=>itemHtml()).join('')}</div><label class="ct-quantity">SỐ LƯỢNG <input id="ct-amount" type="number" min="1" max="1000000" value="${quantity}"><span>Chọn món để đưa vào đề nghị</span></label><p class="ct-help">Bấm vào món trong đề nghị để gỡ ra.<br>Level, serial và thuộc tính được giữ nguyên khi giao dịch.</p></div><div class="ct-middle"><div class="ct-emblem">◈</div><strong>TRADE</strong><small>KHÓA · XÁC NHẬN</small><div class="ct-arrows">⌄<br>⌄</div></div><div class="ct-deal"><h2>GIAO DỊCH VỚI <span>${esc(trade.otherName)}</span></h2><div class="ct-offer"><div class="ct-offer-head"><b>ĐỀ NGHỊ CỦA BẠN</b><span class="ct-status ${trade.locked?'locked':''}">${trade.confirmed?'ĐÃ XÁC NHẬN':trade.locked?'ĐÃ KHÓA':'ĐANG CHỌN'}</span></div><div class="ct-offer-grid">${offerGrid(trade.mine,'mine')}</div><button data-action="lock" class="ct-lock ${trade.locked?'locked':''}">${trade.locked?'▣ MỞ KHÓA ĐỀ NGHỊ':'▢ KHÓA ĐỀ NGHỊ'}</button></div><div class="ct-offer"><div class="ct-offer-head"><b>ĐỀ NGHỊ CỦA ${esc(trade.otherName)}</b><span class="ct-status ${trade.otherLocked?'locked':''}">${trade.otherConfirmed?'ĐÃ XÁC NHẬN':trade.otherLocked?'ĐÃ KHÓA':'ĐANG CHỌN'}</span></div><div class="ct-offer-grid">${offerGrid(trade.theirs,'theirs')}</div></div><button data-action="confirm" class="ct-confirm" ${!trade.locked||!trade.otherLocked||trade.confirmed?'disabled':''}>${trade.confirmed?'ĐANG CHỜ ĐỐI PHƯƠNG…':'✓ XÁC NHẬN GIAO DỊCH'}</button><p class="ct-help">Cả hai cùng khóa và xác nhận để chuyển đồ.<br>Sửa đề nghị sẽ xóa xác nhận của cả hai.</p></div></div><div class="ct-footer"><span><span class="ct-step">1</span>Chọn vật phẩm &nbsp; <span class="ct-step">2</span>Khóa đề nghị &nbsp; <span class="ct-step">3</span>Xác nhận</span><strong>ESC · HỦY GIAO DỊCH</strong></div></div>`;
    $trade().querySelectorAll('img').forEach(img=>img.onerror=()=>{img.hidden=true});
  }
  function show(data){data.mine=list(data.mine);data.theirs=list(data.theirs);trade=data;clock=performance.now();window.CyanTradeActive=true;document.getElementById('qbcore-inventory').style.display='none';$invite().hidden=true;$trade().hidden=false;render()}
  function close(message){trade=null;invite=null;window.CyanTradeActive=false;$trade().hidden=true;$invite().hidden=true;toast(message)}
  function demo(inventory,maxWeight){
    let bag=list(inventory);if(!bag.length)bag=[{slot:1,name:'weapon_pistol',label:'Pistol',type:'weapon',weight:1000,amount:1,image:'weapon_pistol.png',info:{level:3}},{slot:2,name:'water_bottle',label:'Nước suối',weight:500,amount:4,image:'water_bottle.png',info:{level:1}},{slot:3,name:'lockpick',label:'Lockpick',weight:200,amount:2,image:'lockpick.png',info:{level:2}}];
    show({id:'PREVIEW',revision:1,demo:true,otherName:'CYAN PARTNER',otherId:0,inventory:bag,maxWeight:maxWeight||120000,mine:[],theirs:[{...bag[0],slot:1,amount:1}],locked:false,otherLocked:false,confirmed:false,otherConfirmed:false,seconds:180,maxOffers:5});
  }
  function previewAction(action,data){
    if(action==='offer'){
      if(trade.locked)return toast('Mở khóa trước khi sửa.');
      const item=list(trade.inventory).find(x=>x.slot===data.slot);if(!item)return;
      if(data.amount>item.amount)return toast('Không đủ số lượng.');
      const index=trade.mine.findIndex(x=>x.slot===data.slot);
      if(index<0&&trade.mine.length>=5&&data.amount>0)return toast('Tối đa 5 món.');
      if(index>=0)trade.mine.splice(index,1);
      if(data.amount>0)trade.mine.push({...item,amount:data.amount});
      trade.locked=trade.otherLocked=trade.confirmed=trade.otherConfirmed=false;trade.revision++;
    }else if(action==='lock'){trade.locked=!trade.locked;trade.otherLocked=trade.locked;trade.confirmed=false;trade.otherConfirmed=false}
    else if(action==='confirm'){if(!trade.locked||!trade.otherLocked)return;trade.confirmed=trade.otherConfirmed=true;toast('Test thành công. Không có vật phẩm thật được chuyển.')}
    render();
  }
  document.addEventListener('click',e=>{
    const el=e.target.closest('[data-trade-slot]');
    if(el&&trade){
      if(trade.locked)return toast('Mở khóa đề nghị trước khi sửa.');
      if(el.dataset.context==='theirs')return;
      const amount=el.dataset.context==='mine'?0:quantity,slot=Number(el.dataset.tradeSlot);
      if(trade.demo)previewAction('offer',{slot,amount});else post('CyanTradeOffer',{slot,amount});return;
    }
    const action=e.target.closest('[data-action]')?.dataset.action;if(!action)return;
    if(action==='accept'||action==='decline'){$invite().hidden=true;window.CyanTradeActive=false;post('CyanTradeAnswer',{accept:action==='accept'});invite=null;return}
    if(action==='cancel'){post('CyanTradeCancel');close();return}
    if(!trade)return;
    if(trade.demo)previewAction(action,{});else post(action==='lock'?'CyanTradeLock':'CyanTradeConfirm',{revision:trade.revision});
  });
  document.addEventListener('input',e=>{if(e.target.id==='ct-amount')quantity=Math.max(1,Math.min(1000000,Math.floor(Number(e.target.value)||1)))});
  document.addEventListener('keydown',e=>{if(window.CyanTradeActive&&(e.key==='Escape'||e.key==='Tab')){e.preventDefault();e.stopImmediatePropagation();post('CyanTradeCancel');close()}},true);
  window.addEventListener('message',({data:m})=>{
    if(m.action==='cyanTradeState')show(m.data);
    else if(m.action==='cyanTradeClose')close(m.message);
    else if(m.action==='cyanTradePreview')demo(m.inventory,m.maxWeight);
    else if(m.action==='cyanTradeInvite'){
      invite=m.data;clock=performance.now();window.CyanTradeActive=true;
      $invite().innerHTML=`<div class="ci-card"><div class="ct-brand">CYAN EXCHANGE</div><h2>Lời mời giao dịch</h2><p><b>${esc(invite.name)}</b> muốn trao đổi vật phẩm với bạn.</p><span class="ci-timer" id="ci-timer">${invite.seconds}s để trả lời</span><div class="ci-actions"><button data-action="accept">CHẤP NHẬN</button><button data-action="decline">TỪ CHỐI</button></div></div>`;$invite().hidden=false;
    }else if(m.action==='cyanCritical'){const el=document.getElementById('cyan-critical');el.hidden=false;setTimeout(()=>el.hidden=true,700)}
    else if(m.action==='cyanHideInventory'){document.getElementById('qbcore-inventory').style.display='none'}
    else if(m.action==='open'){
      window.CyanWeaponConfig=m.cyanDamage;
      document.getElementById('inv-footer-money').dataset.ready='1';
      document.getElementById('inv-cash-amount').textContent='$'+Number(m.cash||0).toLocaleString();
      document.getElementById('inv-bank-amount').textContent='$'+Number(m.bank||0).toLocaleString();
    }
  });
  setInterval(()=>{
    if(trade){const t=document.getElementById('ct-timer');if(t)t.textContent=Math.max(0,Math.ceil(trade.seconds-(performance.now()-clock)/1000))+'s'}
    if(invite){const t=document.getElementById('ci-timer');if(t)t.textContent=Math.max(0,Math.ceil(invite.seconds-(performance.now()-clock)/1000))+'s để trả lời'}
  },500);
  // Extend original tooltips without removing licenses, serials, attachments or other item info.
  const originalInfo=FormatItemInfo;
  FormatItemInfo=function(item){
    originalInfo(item);if(!item)return;
    const level=QbiGetItemLevel(item),cfg=window.CyanWeaponConfig||{PerLevel:2,CritPerLevel:.10,Excluded:{},CriticalMode:'instant_kill'};
    let html=`<div class="cyan-stat"><span>LEVEL</span><b style="color:${colors[level-1]}">${level} / 6</b></div>`;
    if(item.type==='weapon'||item.name?.startsWith('weapon_')){
      if(cfg.Excluded?.[item.name])html+='<div class="cyan-stat">Không áp dụng bonus chiến đấu</div>';
      else html+=`<div class="cyan-stat"><span>DAMAGE BONUS</span><b>+${level*cfg.PerLevel}</b></div><div class="cyan-stat"><span>TỈ LỆ CHÍ MẠNG</span><b>${Math.round(Math.min(1,level*cfg.CritPerLevel)*100)}%</b></div><div class="cyan-stat"><span>CHÍ MẠNG</span><b>${cfg.CriticalMode==='instant_kill'?'HẠ GỤC':('×'+(cfg.CriticalMultiplier||2))}</b></div>`;
    }
    $('.item-info-description').append(html);
  };
  setInterval(()=>{
    if(document.getElementById('qbcore-inventory').style.display==='none')return;
    $('.item-slot').each(function(){const item=$(this).data('item');let chip=this.querySelector('.cyan-level-chip');if(!item){chip?.remove();return}if(!chip){chip=document.createElement('span');chip.className='cyan-level-chip';this.appendChild(chip)}const level=QbiGetItemLevel(item);chip.textContent='L'+level;chip.style.color=colors[level-1]});
  },450);
})();
