local Core = exports['qb-core']:GetCoreObject()
local activeTrade, invite, preview = nil,nil,false
local damageWeapon, modified = nil,{}
local cfg=CyanConfig.Damage
local melee={};for _,name in ipairs(cfg.Melee) do melee[name]=true end
local function damageBase(name)
    return cfg.BaseDamage[name] or (melee[name] and cfg.MeleeBaseDamage or GetWeaponDamage(joaat(name),0))
end
local function restoreWeapon()
    for hash in pairs(modified) do SetWeaponDamageModifier(hash,1.0) end
    modified={}
end
AddEventHandler('cyan:weaponEquipped',function(item)
    restoreWeapon();damageWeapon=item
    if not cfg.Enabled or not item or cfg.Excluded[item.name] then return end
    local base=damageBase(item.name)
    if not base or base<=0 then return end
    local multiplier=melee[item.name] and cfg.MeleeMultiplier or 1.0
    local target=base*multiplier+CyanLevel(item.info)*cfg.PerLevel
    local hash=joaat(item.name)
    SetWeaponDamageModifier(hash,target/base);modified[hash]=true
end)
RegisterNetEvent('QBCore:Player:SetPlayerData',function(data)
    if not damageWeapon then return end
    local item=data.items and data.items[damageWeapon.slot]
    if not item or item.name~=damageWeapon.name or (item.info and item.info.serie)~=(damageWeapon.info and damageWeapon.info.serie) then
        TriggerEvent('cyan:weaponEquipped',nil)
    else TriggerEvent('cyan:weaponEquipped',item) end
end)
RegisterNetEvent('cyan:criticalHit',function(netId,name,level,mode)
    if source~=65535 then return end
    local victim=NetworkGetEntityFromNetworkId(netId)
    if victim==0 or not DoesEntityExist(victim) or not NetworkHasControlOfEntity(victim) then return end
    if IsEntityDead(victim) then return end
    if mode=='instant_kill' then SetPedArmour(victim,0);SetEntityHealth(victim,0)
    else
        local base=damageBase(name)
        if base and base>0 then
            local damage=(base*(melee[name] and cfg.MeleeMultiplier or 1)+level*cfg.PerLevel)*(cfg.CriticalMultiplier-1)
            ApplyDamageToPed(victim,math.floor(damage),false)
        end
    end
end)
RegisterNetEvent('cyan:criticalNotice',function() SendNUIMessage({action='cyanCritical'}) end)
local function closeTrade(message)
    activeTrade=nil;invite=nil;preview=false
    SetNuiFocus(false,false)
    SendNUIMessage({action='cyanTradeClose',message=message})
end
RegisterNetEvent('cyan:tradeClose',closeTrade)
RegisterNetEvent('cyan:tradeInvite',function(data)
    invite=data
    SetNuiFocus(true,true)
    SendNUIMessage({action='cyanTradeInvite',data=data})
    SetTimeout((data.seconds or 20)*1000,function()
        if invite==data then invite=nil; if not activeTrade then closeTrade('Lời mời hết hạn.') end end
    end)
end)
RegisterNetEvent('cyan:tradeState',function(data)
    if not activeTrade then
        TriggerEvent('cyan:inventoryResetForTrade')
        SetCurrentPedWeapon(PlayerPedId(),joaat('WEAPON_UNARMED'),true)
        TriggerEvent('cyan:weaponEquipped',nil)
    end
    invite=nil;activeTrade=data.id;preview=false
    SendNUIMessage({action='toggleHotbar',open=false})
    SetNuiFocus(true,true)
    SendNUIMessage({action='cyanTradeState',data=data})
end)
RegisterNetEvent('cyan:tradePreview',function()
    if activeTrade then return end
    preview=true
    TriggerEvent('cyan:inventoryResetForTrade')
    SetNuiFocus(true,true)
    SendNUIMessage({action='cyanTradePreview',inventory=Core.Functions.GetPlayerData().items,maxWeight=Config.MaxInventoryWeight})
end)
RegisterNUICallback('CyanTradeAnswer',function(data,cb)
    if invite then TriggerServerEvent('cyan:tradeAnswer',invite.from,data.accept==true) end
    invite=nil;SetNuiFocus(false,false);cb({ok=true})
end)
for _,entry in ipairs({{'CyanTradeOffer','cyan:tradeOffer'},{'CyanTradeLock','cyan:tradeLock'},{'CyanTradeConfirm','cyan:tradeConfirm'}}) do
    local callback,event=entry[1],entry[2]
    RegisterNUICallback(callback,function(data,cb)
        if activeTrade and not preview then
            if callback=='CyanTradeOffer' then TriggerServerEvent(event,activeTrade,data.slot,data.amount)
            else TriggerServerEvent(event,activeTrade,data.revision) end
        end
        cb({ok=true})
    end)
end
RegisterNUICallback('CyanTradeCancel',function(_,cb)
    if activeTrade and not preview then TriggerServerEvent('cyan:tradeCancel',activeTrade) end
    if invite then TriggerServerEvent('cyan:tradeAnswer',invite.from,false) end
    closeTrade();cb({ok=true})
end)
RegisterNUICallback('CyanTradeNearby',function(_,cb)
    local target,distance=Core.Functions.GetClosestPlayer()
    if target~=-1 and distance<=CyanConfig.Trade.Distance then TriggerServerEvent('cyan:tradeRequest',GetPlayerServerId(target))
    else Core.Functions.Notify('Không có người chơi ở gần.','error') end
    cb({ok=true})
end)
local function installTarget()
    if GetResourceState('ox_target')~='started' then return end
    exports.ox_target:removeGlobalPlayer('cyan_inventory_trade')
    exports.ox_target:addGlobalPlayer({{
        name='cyan_inventory_trade',icon='fa-solid fa-right-left',label='Giao dịch vật phẩm',distance=CyanConfig.Trade.Distance,
        canInteract=function(entity)
            return not activeTrade and not LocalPlayer.state.cyan_trade and not IsEntityDead(PlayerPedId()) and not IsEntityDead(entity)
        end,
        onSelect=function(data)
            local index=NetworkGetPlayerIndexFromPed(data.entity)
            if index~=-1 then TriggerServerEvent('cyan:tradeRequest',GetPlayerServerId(index)) end
        end,
    }})
end
CreateThread(installTarget)
AddEventHandler('onClientResourceStart',function(resource) if resource=='ox_target' then installTarget() end end)
AddEventHandler('onResourceStop',function(resource)
    if resource~=GetCurrentResourceName() then return end
    restoreWeapon();SetNuiFocus(false,false)
    if GetResourceState('ox_target')=='started' then exports.ox_target:removeGlobalPlayer('cyan_inventory_trade') end
end)
RegisterNetEvent('QBCore:Client:OnPlayerUnload',function()
    if activeTrade then TriggerServerEvent('cyan:tradeCancel',activeTrade) end
    closeTrade();restoreWeapon();damageWeapon=nil
end)
CreateThread(function()
    while true do
        if activeTrade then DisablePlayerFiring(PlayerId(),true);DisableControlAction(0,24,true);DisableControlAction(0,25,true);Wait(0)
        else Wait(250) end
    end
end)
