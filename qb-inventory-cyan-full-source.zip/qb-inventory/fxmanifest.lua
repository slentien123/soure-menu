fx_version 'cerulean'
game 'gta5'

description 'QB-Inventory'
version '2.1.0-cyan'

shared_scripts {
	'@qb-core/shared/locale.lua',
	'locales/vn.lua', -- Change to the language you want
	'@qb-weapons/config.lua',
    'config.lua',
    'shared/cyan.lua'
}

server_scripts {
	'@oxmysql/lib/MySQL.lua',
	'server/main.lua',
    'server/trade.lua',
    'server/damage.lua'
}
client_scripts { 'client/main.lua', 'client/cyan.lua' }

ui_page {
	'html/ui.html'
}

files {
	'html/ui.html',
	'html/css/main.css',
	'html/js/app.js',
    'html/js/cyan.js',
    'html/css/cyan.css',
    'html/vendor/*',
	'html/images/*.png',
	'html/images/*.jpg',
	'html/ammo_images/*.png',
	'html/attachment_images/*.png',
	'html/*.ttf'
}

lua54 'yes'
