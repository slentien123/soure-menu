# QB Inventory Cyan — full source 2.1

Bản sửa trực tiếp từ qb-inventory.rar và weapondame.rar bạn cung cấp. Bao gồm Lua client/server, toàn bộ ảnh item gốc, NUI và thư viện jQuery/jQuery UI local. Không yêu cầu npm build. Giữ tên thư mục **qb-inventory** vì source gốc dùng tên này cho NUI callbacks.

## Cài đặt

1. Backup resource qb-inventory đang chạy và database `players`, `stashitems`, `trunkitems`, `gloveboxitems`.
2. Thay resource qb-inventory bằng thư mục trong ZIP. Không import lại SQL nếu server đã có các bảng inventory.
3. **Bỏ `ensure weapondame` / stop weapondame cũ**. Damage đã được tích hợp; chạy cả hai sẽ chồng modifier/chí mạng.
4. Giữ qb-core, qb-weapons, oxmysql như server hiện tại. Cài/bật ox_lib và ox_target để có tương tác giao dịch.
5. Thứ tự mẫu:

```cfg
ensure oxmysql
ensure qb-core
ensure qb-weapons
ensure ox_lib
ensure ox_target
ensure qb-inventory
```

Bật OneSync cho xử lý network damage, khoảng cách và routing bucket. Các tích hợp cũ (qb-shops, qb-smallresources, qb-target khi Config.UseTarget=true, âm thanh, crafting, police) vẫn phụ thuộc resource tương ứng của server. ox_target được thêm cho **giao dịch với người chơi**, không thay toàn bộ hệ thống target cũ.

Cần reconnect sau khi thay resource để nhận phím và dữ liệu nhân vật sạch. Test trên server staging với hai người trước khi thay bản production.

## Giao diện và hotbar

- Giao diện cyan/đen trong suốt lấy bố cục từ ảnh tham chiếu: sáu cột vật phẩm, hotbar dọc bên trái, thanh category, tìm kiếm và footer.
- Chín ô thật là **slot 1–9**, dùng bằng phím **1 2 3 4 5 6 7 8 9**. Z bật/tắt hotbar ngang.
- Slot 41 cũ trở thành ô túi bình thường; vật phẩm hiện ở slot 41 không bị xóa, hãy kéo thủ công sang hotbar nếu muốn.
- Vẫn có kéo thả, chuột phải Use/Give/Drop, attachment, kho/thùng xe/cửa hàng theo source gốc.
- Giữ màu level: 1 xám, 2 xanh lá, 3 xanh dương, 4 tím, 5 cam, 6 đỏ.
- Tooltip hiển thị level; vũ khí còn có bonus damage, tỉ lệ và chế độ chí mạng. Đọc `info.level`, tương thích `info.lever`; không có level mặc định 1.
- Bỏ cache level theo tên item để hai món cùng tên nhưng khác level không bị hiển thị nhầm màu. Các stack khác metadata không bị gộp.
- Không có logo/ảnh nền GTA riêng của server mẫu trong ZIP. Ảnh preview dùng dữ liệu minh họa, không nằm trong gameplay.

## Level và weapon damage

Cấu hình: `shared/cyan.lua` → `CyanConfig.Damage`.

| Level | Damage bonus | Tỉ lệ chí mạng |
|---|---:|---:|
| 1 | +2 | 10% |
| 2 | +4 | 20% |
| 3 | +6 | 30% |
| 4 | +8 | 40% |
| 5 | +10 | 50% |
| 6 | +12 | 60% |

Level hiện tại là metadata, không tự tăng bằng XP. Lệnh giveitem gốc có tham số level:

```text
/giveitem ID weapon_pistol 1 3
/giveitem ID weapon_bat 1 6
```

Phần damage thường dùng native modifier trên vũ khí đang cầm, reset khi đổi/hạ vũ khí. Vũ khí bắn đạn dùng base damage từ GTA; weapon custom có thể chỉ định `BaseDamage.weapon_ten = số_damage_gốc`.

Các vũ khí melee trong file weapondame cũ giữ hệ số nền 0.10. Vì native GetWeaponDamage không trả về base damage đáng tin cho melee, cấu hình `MeleeBaseDamage=100` là **mốc cân bằng**, phải điều chỉnh bằng damage thực tế của server hoặc ghi đè từng weapon qua `BaseDamage`. Công thức modifier = `(base * hệ_số_nền + level * 2) / base`. Damage thực nhận còn chịu giáp, khoảng cách, hit location, animation và các script damage khác; bonus +2 là trên damage danh nghĩa, không đảm bảo trừ đúng 2 HP trong mọi tình huống.

Tỉ lệ chí mạng roll ở server từ item/serial đang cầm. Không nhận level hoặc damage do NUI gửi. Client sở hữu ped nạn nhân áp dụng kết quả server. Mặc định `CriticalMode='instant_kill'` giữ cách hoạt động trong weapondame cũ: hạ gục, xóa giáp. Đổi thành `double` để gây thêm damage tương ứng `CriticalMultiplier=2.0`. Headshot GTA mặc định vẫn có thể hạ gục riêng với roll này.

Loại trừ tay không, stun gun, bình xăng, các vật ném/nổ và rocket khỏi bonus. Vũ khí custom unsupported phải khai báo base damage đúng. Tính năng không phải hệ thống chống cheat; cần kiểm tra tương thích qb-weapons/anticheat/death script và các resource khác dùng SetWeaponDamageModifier.

## Giao dịch qua ox_target

Nhìn vào người chơi gần bằng ox_target → **Giao dịch vật phẩm** → đối phương chấp nhận.

1. Chọn số lượng rồi bấm món trong túi; tối đa 5 loại vật phẩm mỗi người.
2. Bấm món trong đề nghị để gỡ. Mỗi lần sửa tự bỏ khóa/xác nhận của cả hai.
3. Hai người bấm **Khóa đề nghị**.
4. Hai người bấm **Xác nhận giao dịch**. Chỉ khi đủ cả hai xác nhận ở cùng phiên bản đề nghị mới chuyển đồ.
5. Mở khóa sẽ yêu cầu cả hai khóa và xác nhận lại. ESC/× hủy; timeout, đi xa, chết, đổi nhân vật hoặc disconnect cũng hủy.

Đây là giao dịch **vật phẩm**; không chuyển cash/bank hoặc thêm nút tiền giả. Túi đối phương không bị lộ ngoài các món họ đưa vào đề nghị.

Server kiểm tra người trong phiên, revision, slot, số lượng nguyên dương, số lượng đang có, metadata/serial, tải trọng, ô trống, khoảng cách và bucket. Dựng hai túi kết quả trước rồi cập nhật trong cùng lượt xử lý không yield. Sửa inventory qua các export chính của resource sẽ hủy phiên; mutation trong lúc commit bị chặn. Resource khác ghi trực tiếp `PlayerData.items` không đi qua export phải tự tích hợp; final validation vẫn kiểm tra các item đang chào bán.

Hai inventory được lưu bằng một MySQL transaction. Việc cập nhật live PlayerData và lưu database không phải một transaction phân tán: sự cố mất điện/crash hoặc DB mất kết nối giữa hai bước cần đối soát log `Cyan trade`. Không tuyên bố đảm bảo chống mất/nhân đồ khi crash; DB failure được ghi server console. Backend inventory gốc vẫn giữ các endpoint/tích hợp của bản bạn gửi và cần audit độc lập nếu server public.

## Admin test giao diện

```text
/testtrade
```

Yêu cầu quyền `admin` của QBCore. Mở preview có thao tác chọn món, khóa/mở khóa, xác nhận; đối tác test tự khóa cùng admin. Preview không gửi giao dịch và không chuyển item thật. Khi inventory rỗng, hiện vài món mẫu. Chế độ này không thay thế kiểm thử hai người trên FiveM.

## Kiểm thử đã chạy

- Parse JavaScript và Lua (cú pháp riêng của Cfx được chuẩn hóa tạm để parse Lua 5.4).
- Trình duyệt Chromium: 9 hotbar dọc/ngang, đủ slot túi, tooltip, admin preview, khóa/xác nhận, Escape, từ chối invite, không lỗi JavaScript.
- `tests/trade_spec.lua`: đủ hai khóa/xác nhận, partial stack, metadata, replay, số lượng âm/lẻ/vượt số đang có, revision cũ, người ngoài phiên, quá khoảng cách, quá tải, metadata thay đổi, disconnect và mutation bên ngoài.
- `tests/damage_spec.lua`: công thức damage, reset modifier, level clamp, tỉ lệ roll, chặn hit trùng và serial không khớp.
- **Chưa chạy server FiveM thật**. Cần thử với hai client: combat, giáp/headshot, ox_target, kho xe/stash/shop, restart/disconnect và DB trên bộ framework của bạn.

Có thể chạy test Lua từ thư mục qb-inventory với Lua 5.4:
```sh
lua tests/trade_spec.lua
lua tests/damage_spec.lua
```

## Tài liệu API đối chiếu

- [FiveM SetWeaponDamageModifier](https://docs.fivem.net/natives/?_0x4757F00BC6323CFE=)
- [FiveM GetWeaponDamage và giới hạn melee](https://docs.fivem.net/natives/?_0x3133B907D8B32053=)
- [FiveM server events: weaponDamageEvent](https://docs.fivem.net/docs/scripting-reference/events/server-events/)
- [ox_target client exports](https://overextended.dev/docs/ox_target/Functions/Client)
