QB-INVENTORY REFERENCE UI FINAL

- Giao diện kho đồ theo ảnh tham chiếu: cream/pink, khung lớn, hotbar 2x4, kho 6 cột, panel thông tin bên phải.
- 8 hotbar slots, phím 1-8.
- Drag/drop inventory <-> hotbar và giữa các slot vẫn dùng SetInventoryData của qb-inventory.
- Oẳn tù tì với người gần nhất: người nhận phải xác nhận, server kiểm tra khoảng cách/trạng thái/lựa chọn.
- Đã thêm fallback Lang để không crash khi locale chưa được load.
- Giữ các callback/event inventory gốc: Use/Give/Drop/Combine/Attachments/Stash/Trunk/Glovebox/Shop/Crafting/Robbing...

INSTALL:
1. Backup qb-inventory cũ.
2. Copy resource này thành resources/[qb]/qb-inventory.
3. Giữ toàn bộ ảnh item của inventory cũ trong html/images, ammo_images, attachment_images.
4. Đảm bảo qb-core và oxmysql chạy trước qb-inventory.
5. restart qb-inventory hoặc restart server.

Nếu đang dùng tên resource khác, sửa URL NUI https://qb-inventory/... thành tên resource tương ứng.
