CyanConfig = {
    Trade = { Distance = 2.5, InviteSeconds = 20, SessionSeconds = 180, MaxOffers = 5, CooldownSeconds = 3 },
    Damage = {
        Enabled = true, PerLevel = 2, CritPerLevel = 0.10, MaxLevel = 6,
        CriticalMode = 'instant_kill', -- 'double' or original weapondame instant kill
        CriticalMultiplier = 2.0,
        -- Original weapondame melee modifier. Level bonus is applied after this reduction.
        MeleeMultiplier = 0.10,
        MeleeBaseDamage = 100, -- GTA melee varies by animation; tune per server below.
        Melee = { 'weapon_dagger','weapon_knife','weapon_knuckle','weapon_machete','weapon_switchblade',
            'weapon_battleaxe','weapon_knuckleduster','weapon_pipewrench','weapon_hatchet','weapon_crowbar','weapon_golfclub','weapon_bat',
            'weapon_bottle','weapon_flashlight','weapon_poolcue','weapon_stone_hatchet','weapon_wrench','weapon_hammer' },
        Excluded = {weapon_unarmed=true, weapon_stungun=true, weapon_petrolcan=true, weapon_fireextinguisher=true,
            weapon_snowball=true,weapon_ball=true,weapon_grenade=true,weapon_stickybomb=true,weapon_pipebomb=true,
            weapon_smokegrenade=true,weapon_flare=true,weapon_proxmine=true,weapon_molotov=true,weapon_bzgas=true,
            weapon_rpg=true,weapon_hominglauncher=true,weapon_grenadelauncher=true,weapon_railgun=true},
        -- BaseDamage overrides allow exact balancing of custom weapons.
        BaseDamage = {},
    },
}
function CyanLevel(info)
    local level = type(info) == 'table' and tonumber(info.level or info.lever) or 1
    if not level or level ~= level then level = 1 end
    return math.max(1, math.min(6, math.floor(level)))
end
function CyanEqual(a, b)
    if type(a) ~= type(b) then return false end
    if type(a) ~= 'table' then return a == b end
    for k,v in pairs(a) do if not CyanEqual(v,b[k]) then return false end end
    for k in pairs(b) do if a[k] == nil then return false end end
    return true
end
function CyanCopy(value)
    if type(value) ~= 'table' then return value end
    local out = {}; for k,v in pairs(value) do out[k] = CyanCopy(v) end; return out
end
