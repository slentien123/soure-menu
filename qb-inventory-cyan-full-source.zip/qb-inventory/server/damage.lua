local Core = exports['qb-core']:GetCoreObject()
local equipped, recent = {}, {}
local cfg = CyanConfig.Damage
function CyanDamageClear(src) equipped[src]=nil end
function CyanDamageEquip(src, item)
    local old=equipped[src]
    if old and old.slot==item.slot and old.name==item.name then equipped[src]=nil;return end
    equipped[src]={slot=item.slot,name=item.name,serie=type(item.info)=='table' and item.info.serie}
end
AddEventHandler('playerDropped',function() equipped[source]=nil;recent[source]=nil end)
-- Critical chance and level come from the server's current inventory, never a NUI payload.
AddEventHandler('weaponDamageEvent',function(sender,data)
    if not cfg.Enabled or type(data) ~= 'table' or not tonumber(data.weaponType) then return end
    local src=tonumber(sender);local p=Core.Functions.GetPlayer(src);local selected=equipped[src]
    if not p or not selected or CyanTrade.isBusy(src) then return end
    local item=p.PlayerData.items[selected.slot]
    if not item or item.name~=selected.name or (item.info and item.info.serie)~=selected.serie or cfg.Excluded[item.name] then return end
    if (joaat(item.name) & 0xffffffff)~=(tonumber(data.weaponType) & 0xffffffff) then return end
    if type(item.info)=='table' and tonumber(item.info.quality) and item.info.quality<=0 then return end
    local targets=data.hitGlobalIds
    if type(targets)~='table' or #targets==0 then targets={data.hitGlobalId} end
    if type(targets)~='table' then return end
    recent[src]=recent[src] or {}
    for _,netId in ipairs(targets) do
        netId=tonumber(netId)
        if netId and netId>0 then
            local victim=NetworkGetEntityFromNetworkId(netId)
            local ped=GetPlayerPed(src)
            if victim~=0 and DoesEntityExist(victim) and GetEntityType(victim)==1 and victim~=ped then
                local owner=NetworkGetEntityOwner(victim)
                local key=tostring(netId)..':'..tostring(data.damageTime)
                local stamp=GetGameTimer()
                for k,v in pairs(recent[src]) do if stamp-v>2000 then recent[src][k]=nil end end
                if owner and owner>0 and GetPlayerRoutingBucket(src)==GetPlayerRoutingBucket(owner)
                    and #(GetEntityCoords(ped)-GetEntityCoords(victim))<300
                    and not recent[src][key] then
                    recent[src][key]=stamp
                    if math.random()<math.min(1,CyanLevel(item.info)*cfg.CritPerLevel) then
                        TriggerClientEvent('cyan:criticalHit',owner,netId,item.name,CyanLevel(item.info),cfg.CriticalMode)
                        TriggerClientEvent('cyan:criticalNotice',src)
                    end
                end
            end
        end
    end
end)
