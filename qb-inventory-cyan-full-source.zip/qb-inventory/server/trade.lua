local Core = exports['qb-core']:GetCoreObject()
local cfg = CyanConfig.Trade
local sessions, membership, invites, cooldown = {}, {}, {}, {}
local sequence = 0
CyanTrade = {}
local function player(src) return Core.Functions.GetPlayer(tonumber(src)) end
local function notify(src, message) TriggerClientEvent('QBCore:Notify', src, message, 'error') end
local function ready(src)
    local p = player(src)
    if not p then return false end
    local m = p.PlayerData.metadata or {}
    local ped = GetPlayerPed(src)
    return ped and ped ~= 0 and GetEntityHealth(ped) > 0 and not m.isdead and not m.inlaststand and not m.ishandcuffed
end
local function near(a,b)
    return a ~= b and ready(a) and ready(b) and GetPlayerRoutingBucket(a) == GetPlayerRoutingBucket(b)
        and #(GetEntityCoords(GetPlayerPed(a))-GetEntityCoords(GetPlayerPed(b))) <= cfg.Distance
end
local function name(src)
    local p = player(src); local c = p and p.PlayerData.charinfo or {}
    return ((c.firstname or '') .. ' ' .. (c.lastname or '')):match('^%s*(.-)%s*$')
end
local function state(src, value)
    if GetPlayerName(src) then Player(src).state:set('cyan_trade', value, true) end
end
local function finish(s, message)
    sessions[s.id] = nil
    for _,src in ipairs(s.people) do
        membership[src] = nil
        state(src, false)
        TriggerClientEvent('cyan:tradeClose',src,message)
    end
end
function CyanTrade.isBusy(src) return membership[tonumber(src)] ~= nil end
function CyanTrade.beforeMutation(src)
    local s = sessions[membership[tonumber(src)]]
    if not s then return true end
    if s.committing then return false end
    finish(s, 'Giao dịch đã hủy vì túi đồ thay đổi.')
    return true
end
local function offerItems(s, src)
    local items={}
    for _,row in ipairs(s.offers[src]) do
        local item=CyanCopy(row.item); item.amount=row.amount; items[#items+1]=item
    end
    return items
end
local function publish(s)
    for i,src in ipairs(s.people) do
        local other=s.people[3-i];local p=player(src)
        TriggerClientEvent('cyan:tradeState',src,{
            id=s.id, revision=s.revision, otherName=name(other), otherId=other,
            inventory=p and p.PlayerData.items or {}, maxWeight=Config.MaxInventoryWeight,
            mine=offerItems(s,src), theirs=offerItems(s,other), locked=s.locked[src], otherLocked=s.locked[other],
            confirmed=s.confirmed[src], otherConfirmed=s.confirmed[other],
            seconds=math.max(0,s.expires-os.time()), maxOffers=cfg.MaxOffers,
        })
    end
end
local function resolve(src,id)
    if type(id) ~= 'string' then return end
    local s=sessions[id]
    if not s or membership[src]~=id or s.committing then return end
    if os.time() >= s.expires or not near(s.people[1],s.people[2]) then finish(s,'Giao dịch đã hết hạn hoặc hai người ở quá xa.');return end
    for _,who in ipairs(s.people) do
        local p=player(who)
        if not p or p.PlayerData.citizenid~=s.identities[who] then finish(s,'Nhân vật đã thay đổi.'); return end
    end
    return s
end
local function clearConsent(s)
    s.revision=s.revision+1
    for _,src in ipairs(s.people) do s.locked[src]=false;s.confirmed[src]=false end
end
local function validOffer(p, rows)
    for _,row in ipairs(rows) do
        local actual=p.PlayerData.items[row.slot]
        if not actual or actual.name~=row.item.name or actual.amount<row.amount or not CyanEqual(actual.info,row.item.info) then return false end
    end
    return true
end
-- Simulate the complete swap first, preserving every metadata field and serial.
local function removeOffers(items, rows)
    for _,row in ipairs(rows) do
        local item=items[row.slot];item.amount=item.amount-row.amount
        if item.amount==0 then items[row.slot]=nil end
    end
end
local function receive(items, rows)
    for _,row in ipairs(rows) do
        local item=row.item; local target
        if not item.unique and item.type~='weapon' then
            for slot,existing in pairs(items) do
                if existing.name==item.name and CyanEqual(existing.info,item.info) then target=slot;break end
            end
        end
        if target then items[target].amount=items[target].amount+row.amount
        else
            for slot=1,Config.MaxInventorySlots do if not items[slot] then target=slot;break end end
            if not target then return false end
            items[target]=CyanCopy(item);items[target].amount=row.amount;items[target].slot=target
        end
    end
    local weight=0
    for _,item in pairs(items) do weight=weight+(tonumber(item.weight) or 0)*item.amount end
    return weight<=Config.MaxInventoryWeight
end
local function commit(s)
    local a,b=s.people[1],s.people[2];local pa,pb=player(a),player(b)
    if not validOffer(pa,s.offers[a]) or not validOffer(pb,s.offers[b]) then finish(s,'Vật phẩm đã thay đổi. Giao dịch bị hủy.');return end
    if #s.offers[a]+#s.offers[b]==0 then notify(a,'Chưa có vật phẩm để trao đổi.');notify(b,'Chưa có vật phẩm để trao đổi.');clearConsent(s);publish(s);return end
    local ia,ib=CyanCopy(pa.PlayerData.items),CyanCopy(pb.PlayerData.items)
    removeOffers(ia,s.offers[a]);removeOffers(ib,s.offers[b])
    if not receive(ia,s.offers[b]) or not receive(ib,s.offers[a]) then clearConsent(s);publish(s);notify(a,'Không đủ ô trống hoặc quá tải trọng.');notify(b,'Không đủ ô trống hoặc quá tải trọng.');return end
    s.committing=true
    -- No yielding between validation and both in-memory assignments.
    pa.Functions.SetPlayerData('items',ia)
    pb.Functions.SetPlayerData('items',ib)
    for _,src in ipairs(s.people) do
        for _,row in ipairs(s.offers[src]) do TriggerClientEvent('inventory:client:CheckWeapon',src,row.item.name) end
    end
    -- Persist both inventories together. Normal QB persistence remains in effect.
    local function compact(items)
        local list={};for slot,item in pairs(items) do list[#list+1]={name=item.name,amount=item.amount,info=item.info,type=item.type,slot=slot} end
        return json.encode(list)
    end
    MySQL.transaction({
        {query='UPDATE players SET inventory = ? WHERE citizenid = ?',values={compact(ia),s.identities[a]}},
        {query='UPDATE players SET inventory = ? WHERE citizenid = ?',values={compact(ib),s.identities[b]}},
    },function(ok)
        if not ok then print(('[cyan trade] Persistence failed for trade %s; save online players immediately.'):format(s.id)) end
    end)
    TriggerEvent('qb-log:server:CreateLog','playerinventory','Cyan trade','cyan',json.encode({id=s.id,a=s.identities[a],b=s.identities[b],offers=s.offers}))
    finish(s,'Giao dịch thành công.')
end
RegisterNetEvent('cyan:tradeRequest',function(target)
    local src=source;target=tonumber(target)
    if not target or target%1~=0 or not near(src,target) then return notify(src,'Không tìm thấy người chơi ở gần.') end
    if membership[src] or membership[target] then return notify(src,'Một người đang giao dịch.') end
    if (cooldown[src] or 0)>os.time() then return end;cooldown[src]=os.time()+cfg.CooldownSeconds
    if invites[target] and invites[target].expires>os.time() then return notify(src,'Người chơi đang có lời mời khác.') end
    invites[target]={from=src,expires=os.time()+cfg.InviteSeconds,citizen=player(src).PlayerData.citizenid,targetCitizen=player(target).PlayerData.citizenid}
    TriggerClientEvent('cyan:tradeInvite',target,{from=src,name=name(src),seconds=cfg.InviteSeconds})
    TriggerClientEvent('QBCore:Notify',src,'Đã gửi lời mời giao dịch.','success')
end)
RegisterNetEvent('cyan:tradeAnswer',function(from,accept)
    local src=source;local invite=invites[src];invites[src]=nil
    if not invite or invite.from~=tonumber(from) or invite.expires<os.time() then return end
    if accept~=true then return notify(invite.from,'Lời mời đã bị từ chối.') end
    local a,b=invite.from,src
    if not near(a,b) or membership[a] or membership[b] then return notify(src,'Không thể bắt đầu giao dịch.') end
    if player(a).PlayerData.citizenid~=invite.citizen or player(b).PlayerData.citizenid~=invite.targetCitizen then return end
    -- Do not start while someone is using another inventory (stash, trunk or shop).
    if Player(a).state.inv_busy or Player(b).state.inv_busy then return notify(src,'Hãy đóng kho đồ đang mở trước khi giao dịch.') end
    sequence=sequence+1;local id=('%s:%s'):format(os.time(),sequence)
    local s={id=id,people={a,b},offers={[a]={},[b]={}},locked={[a]=false,[b]=false},confirmed={[a]=false,[b]=false},revision=1,
        identities={[a]=invite.citizen,[b]=invite.targetCitizen},expires=os.time()+cfg.SessionSeconds}
    sessions[id]=s;membership[a]=id;membership[b]=id;state(a,true);state(b,true)
    if CyanDamageClear then CyanDamageClear(a);CyanDamageClear(b) end
    publish(s)
end)
RegisterNetEvent('cyan:tradeOffer',function(id,slot,amount)
    local src=source;local s=resolve(src,id);if not s then return end
    slot=tonumber(slot);amount=tonumber(amount)
    if not slot or not amount or slot%1~=0 or amount%1~=0 or amount<0 or amount>1000000 then return end
    if s.locked[src] then return notify(src,'Mở khóa trước khi sửa vật phẩm.') end
    local rows=s.offers[src];local index
    for i,row in ipairs(rows) do if row.slot==slot then index=i;break end end
    if amount==0 then if index then table.remove(rows,index) else return end
    else
        local item=player(src).PlayerData.items[slot]
        if not item or amount>item.amount then return notify(src,'Số lượng không hợp lệ.') end
        if not index and #rows>=cfg.MaxOffers then return notify(src,'Tối đa '..cfg.MaxOffers..' loại vật phẩm mỗi lượt.') end
        rows[index or #rows+1]={slot=slot,amount=amount,item=CyanCopy(item)}
    end
    clearConsent(s);publish(s)
end)
RegisterNetEvent('cyan:tradeLock',function(id,revision)
    local src=source;local s=resolve(src,id);if not s or revision~=s.revision then return end
    if s.locked[src] then clearConsent(s) else s.locked[src]=true;s.confirmed[src]=false end
    publish(s)
end)
RegisterNetEvent('cyan:tradeConfirm',function(id,revision)
    local src=source;local s=resolve(src,id);if not s or revision~=s.revision then return end
    if not s.locked[s.people[1]] or not s.locked[s.people[2]] then return notify(src,'Cả hai cần khóa đề nghị trước.') end
    s.confirmed[src]=true
    if s.confirmed[s.people[1]] and s.confirmed[s.people[2]] then commit(s) else publish(s) end
end)
RegisterNetEvent('cyan:tradeCancel',function(id)
    local src=source;local s=resolve(src,id);if s then finish(s,'Giao dịch đã hủy.') end
end)
AddEventHandler('playerDropped',function()
    local src=source;local s=sessions[membership[src]]
    if s then finish(s,'Người chơi đã ngắt kết nối.') end
    invites[src]=nil;cooldown[src]=nil
    for who,invite in pairs(invites) do if invite.from==src then invites[who]=nil end end
end)
CreateThread(function()
    while true do
        Wait(1000)
        for _,s in pairs(sessions) do resolve(s.people[1],s.id) end
        for src,invite in pairs(invites) do if invite.expires<os.time() then invites[src]=nil end end
    end
end)
AddEventHandler('onResourceStop',function(resource)
    if resource~=GetCurrentResourceName() then return end
    for _,s in pairs(sessions) do finish(s,'Resource giao dịch đã dừng.') end
end)
Core.Commands.Add('testtrade','Xem giao diện giao dịch Cyan (không chuyển đồ)',{},false,function(src)
    if src==0 then return end
    TriggerClientEvent('cyan:tradePreview',src)
end,'admin')
