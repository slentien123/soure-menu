-- SERVER ONLY. Never move this file to shared_scripts.
Config.Discord = {
    BotToken = '', -- Put a Discord bot token here if you want CDN avatars from Discord.
    UseBotAvatar = true
}
