local RESOURCE = GetCurrentResourceName()
local QBCore, ESX
local Framework = nil
local Codes = {}
local Parties = {}
local PlayerState = {}
local giftCodePayload
local Sessions = {}
local EventState = {}
local Profiles = {}
local function saveProfiles() SaveResourceFile(RESOURCE, "data/profiles.json", json.encode(Profiles), -1) end
local rawProfiles = LoadResourceFile(RESOURCE, "data/profiles.json")
if rawProfiles then local ok, value = pcall(json.decode, rawProfiles); if ok and type(value) == "table" then Profiles = value end end

local function log(...)
    if Config.Debug then print(('[%s]'):format(RESOURCE), ...) end
end

local function detectFramework()
    if Config.Framework == 'qb' or (Config.Framework == 'auto' and GetResourceState(Config.Resources.QBCore) == 'started') then
        local ok, obj = pcall(function() return exports[Config.Resources.QBCore]:GetCoreObject() end)
        if ok and obj then QBCore = obj; Framework = 'qb'; return end
    end
    if Config.Framework == 'esx' or (Config.Framework == 'auto' and GetResourceState(Config.Resources.ESX) == 'started') then
        local ok, obj = pcall(function() return exports[Config.Resources.ESX]:getSharedObject() end)
        if ok and obj then ESX = obj; Framework = 'esx'; return end
    end
    Framework = 'standalone'
end

detectFramework()

local function saveCodes()
    SaveResourceFile(RESOURCE, Config.GiftCodeFile, json.encode(Codes), -1)
end

local function loadCodes()
    local raw = LoadResourceFile(RESOURCE, Config.GiftCodeFile)
    if raw and raw ~= '' then
        local ok, data = pcall(json.decode, raw)
        if ok and type(data) == 'table' then Codes = data end
    end
end

local function identifier(src)
    if Framework == 'qb' then
        local p = QBCore.Functions.GetPlayer(src)
        return p and p.PlayerData.citizenid or GetPlayerIdentifierByType(src, 'license') or ('src:' .. src)
    elseif Framework == 'esx' then
        local p = ESX.GetPlayerFromId(src)
        return p and p.identifier or GetPlayerIdentifierByType(src, 'license') or ('src:' .. src)
    end
    return GetPlayerIdentifierByType(src, 'license') or ('src:' .. src)
end

local function playerName(src)
    if Framework == 'qb' then
        local p = QBCore.Functions.GetPlayer(src)
        if p then
            local c = p.PlayerData.charinfo or {}
            return (c.firstname or '') .. ' ' .. (c.lastname or '')
        end
    elseif Framework == 'esx' then
        local p = ESX.GetPlayerFromId(src)
        if p then return p.getName() end
    end
    return GetPlayerName(src) or ('Player ' .. src)
end

local function isAdmin(src)
    if src == 0 then return true end
    if IsPlayerAceAllowed(src, Config.Admin.Ace) then return true end
    if Framework == 'qb' then
        local p = QBCore.Functions.GetPlayer(src)
        if p then
            local perm = p.PlayerData.permission
            if perm == 'god' or perm == 'admin' or perm == 'mod' then return true end
            local group = p.PlayerData.job and p.PlayerData.job.name
            for _, g in ipairs(Config.Admin.FrameworkGroups) do if group == g then return true end end
        end
    elseif Framework == 'esx' then
        local p = ESX.GetPlayerFromId(src)
        if p then
            local group = p.getGroup()
            for _, g in ipairs(Config.Admin.FrameworkGroups) do if group == g then return true end end
        end
    end
    return false
end

local function rewardItem(src, name, amount, metadata)
    amount = tonumber(amount) or 1
    if Framework == 'qb' then
        local p = QBCore.Functions.GetPlayer(src)
        if not p then return false end
        return p.Functions.AddItem(name, amount, false, metadata or false, 'cyan_panel:giftcode')
    elseif Framework == 'esx' then
        local p = ESX.GetPlayerFromId(src)
        if not p then return false end
        p.addInventoryItem(name, amount)
        return true
    end
    return false
end

local function rewardMoney(src, account, amount)
    amount = tonumber(amount) or 0
    if Framework == 'qb' then
        local p = QBCore.Functions.GetPlayer(src)
        return p and p.Functions.AddMoney(account or 'cash', amount, 'cyan_panel:giftcode') or false
    elseif Framework == 'esx' then
        local p = ESX.GetPlayerFromId(src)
        if not p then return false end
        account = account == 'cash' and 'money' or account
        p.addAccountMoney(account, amount)
        return true
    end
    return false
end

local function rewardWeapon(src, weapon, ammo)
    ammo = tonumber(ammo) or 0
    if Framework == 'qb' then
        -- QB normally treats weapons as inventory items. Use AddItem so qb-inventory handles it.
        local p = QBCore.Functions.GetPlayer(src)
        return p and p.Functions.AddItem(weapon, 1, false, { ammo = ammo }, 'cyan_panel:giftcode') or false
    elseif Framework == 'esx' then
        local p = ESX.GetPlayerFromId(src)
        if not p then return false end
        p.addWeapon(weapon, ammo)
        return true
    end
    return false
end

local function grantRewards(src, rewards)
    for _, r in ipairs(rewards or {}) do
        if r.type == 'item' then
            rewardItem(src, r.name, r.amount, r.metadata)
        elseif r.type == 'money' then
            rewardMoney(src, r.account or 'cash', r.amount)
        elseif r.type == 'weapon' then
            rewardWeapon(src, r.name, r.amount)
        end
    end
end

local function getDiscordIdentifier(src)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'discord:' then return id:sub(9) end
    end
end

local function fetchDiscordAvatar(src, cb)
    if not Config.Discord.UseBotAvatar or Config.Discord.BotToken == '' then return cb(nil) end
    local did = getDiscordIdentifier(src)
    if not did then return cb(nil) end
    PerformHttpRequest('https://discord.com/api/v10/users/' .. did, function(code, body)
        if code ~= 200 or not body then return cb(nil) end
        local ok, data = pcall(json.decode, body)
        if not ok or not data then return cb(nil) end
        if data.avatar then
            local ext = data.avatar:sub(1, 2) == 'a_' and 'gif' or 'png'
            return cb(('https://cdn.discordapp.com/avatars/%s/%s.%s?size=256'):format(did, data.avatar, ext))
        end
        cb(nil)
    end, 'GET', '', { ['Authorization'] = 'Bot ' .. Config.Discord.BotToken })
end

local function getAvatar(src, cb)
    local st = Player(src)
    if st and st.state then
        local avatar = st.state.avatar or st.state.profilePicture or st.state.avatarUrl
        if type(avatar) == 'string' and avatar ~= '' then return cb(avatar) end
    end
    fetchDiscordAvatar(src, function(url) cb(url or Config.DefaultAvatar) end)
end

local function getSettings(src)
    PlayerState[src] = PlayerState[src] or { settings = {} }
    local saved = Profiles[identifier(src)]
    if saved and saved.settings then PlayerState[src].settings = saved.settings end
    local s = PlayerState[src].settings
    for k, v in pairs(Config.Settings) do if s[k] == nil then s[k] = v end end
    return s
end

local function onlineCount()
    return #GetPlayers()
end

local function partyFor(src)
    for id, p in pairs(Parties) do
        for _, member in ipairs(p.members) do if member == src then return id, p end end
    end
end

local function partyPayload()
    local list = {}
    for id, p in pairs(Parties) do
        local members = {}
        for _, src in ipairs(p.members) do
            members[#members+1] = { source = src, name = playerName(src), avatar = Config.DefaultAvatar }
        end
        list[#list+1] = { id = id, name = p.name, private = p.private, members = #p.members, max = p.max, owner = p.owner, invite = nil }
    end
    table.sort(list, function(a,b) return a.id < b.id end)
    return list
end

local function playerPayload(src)
    local p = {
        id = src,
        name = playerName(src),
        platformName = playerName(src),
        rank = 'UNRANK',
        kills = 0,
        deaths = 0,
        mmr = 0,
        accuracy = 0,
        online = onlineCount(),
        framework = Framework,
        isAdmin = isAdmin(src)
    }
    if Framework == 'qb' then
        local q = QBCore.Functions.GetPlayer(src)
        if q then
            p.citizenid = q.PlayerData.citizenid
            p.job = q.PlayerData.job and q.PlayerData.job.label or ''
        end
    elseif Framework == 'esx' then
        local e = ESX.GetPlayerFromId(src)
        if e then p.identifier = e.identifier; p.job = e.job and e.job.label or '' end
    end
    local saved = Profiles[identifier(src)]
    for k,v in pairs(saved and saved.stats or {}) do if k == 'kills' or k == 'deaths' or k == 'mmr' or k == 'accuracy' or k == 'rank' then p[k] = v end end
    return p
end

local function profile(src)
    local id = identifier(src)
    if not Profiles[id] then
        local pin
        repeat pin = ('CP-%08d'):format(math.random(0, 99999999))
            local duplicate = false
            for _, p in pairs(Profiles) do if p.pin == pin then duplicate = true end end
        until not duplicate
        Profiles[id] = { pin = pin, referrals = 0, mailbox = {}, settings = {} }
        saveProfiles()
    end
    return Profiles[id]
end
local function session(src)
    Sessions[src] = Sessions[src] or os.time()
    return Sessions[src]
end
local function eventPayload(src)
    local list = {}
    for _, card in ipairs(Config.EventCards) do
        local runtime = EventState[card.id] or { members = {}, status = 'unavailable' }
        local copy = {}
        for k,v in pairs(card) do copy[k] = v end
        local count = 0
        for member in pairs(runtime.members) do if GetPlayerName(member) then count = count + 1 end end
        copy.players = count
        copy.endsAt = runtime.endsAt
        copy.seconds = nil
        copy.status = runtime.status
        copy.joined = runtime.members[src] == true
        if runtime.endsAt and runtime.endsAt <= os.time() then copy.status = 'ended' end
        list[#list+1] = copy
    end
    return list
end
local function syncEvents()
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        TriggerClientEvent('cyan_panel:client:sync', src, {serverNow = os.time(), sessionStartedAt = session(src), events = eventPayload(src)})
    end
end
-- Server-only API. The actual game resource supplies its authoritative roster.
exports('SetEventState', function(id, payload)
    local known = false
    for _, card in ipairs(Config.EventCards) do if card.id == id then known = true end end
    if not known or type(payload) ~= 'table' then return false end
    if payload.status ~= 'open' and payload.status ~= 'running' and payload.status ~= 'ended' and payload.status ~= 'unavailable' then return false end
    local members = {}
    for _, value in ipairs(payload.players or {}) do
        local src = tonumber(value)
        if src and GetPlayerName(src) then members[src] = true end
    end
    EventState[id] = {members = members, endsAt = tonumber(payload.endsAt), status = payload.status}
    syncEvents()
    return true
end)
exports('SetPlayerStats', function(src, stats)
    local data = profile(src)
    data.stats = stats
    saveProfiles()
end)
exports('SendMail', function(src, title, message)
    local data = profile(src)
    table.insert(data.mailbox, 1, {title = tostring(title), text = tostring(message), time = os.date('%d/%m/%Y %H:%M'), unread = true})
    while #data.mailbox > 100 do table.remove(data.mailbox) end
    saveProfiles()
    TriggerClientEvent('cyan_panel:client:refreshData', src, {mailbox = data.mailbox})
end)
AddEventHandler('playerJoining', function() Sessions[source] = os.time() end)
CreateThread(function()
    for _, id in ipairs(GetPlayers()) do session(tonumber(id)) end
    while true do Wait(3000); syncEvents() end
end)
RegisterNetEvent('cyan_panel:server:sync', function()
    local src = source
    TriggerClientEvent('cyan_panel:client:sync', src, {serverNow = os.time(), sessionStartedAt = session(src), events = eventPayload(src)})
end)
RegisterNetEvent('cyan_panel:server:submitPin', function(pin)
    local src = source
    local data = profile(src)
    if data.referredBy then TriggerClientEvent('cyan_panel:client:toast', src, 'You already used a friend PIN', 'error'); return end
    pin = tostring(pin):upper():gsub('%s+', '')
    for id, target in pairs(Profiles) do
        if target.pin == pin and id ~= identifier(src) then
            data.referredBy = pin
            target.referrals = (target.referrals or 0) + 1
            saveProfiles()
            TriggerClientEvent('cyan_panel:client:toast', src, 'Friend PIN linked successfully', 'success')
            TriggerClientEvent('cyan_panel:client:refreshData', src, {referral = {code=data.pin, redeemed=data.referrals, referredBy=data.referredBy}})
            return
        end
    end
    TriggerClientEvent('cyan_panel:client:toast', src, 'Invalid PIN or your own PIN', 'error')
end)
RegisterNetEvent('cyan_panel:server:readMail', function()
    local data = profile(source)
    for _, mail in ipairs(data.mailbox) do mail.unread = false end
    saveProfiles()
    TriggerClientEvent('cyan_panel:client:refreshData', source, {mailbox = data.mailbox})
end)

RegisterNetEvent('cyan_panel:server:open', function()
    local src = source
    getAvatar(src, function(avatar)
        TriggerClientEvent('cyan_panel:client:openData', src, {
            player = playerPayload(src), avatar = avatar, settings = getSettings(src), availableSettings = Config.AvailableSettings,
            events = eventPayload(src), parties = partyPayload(), serverNow = os.time(), sessionStartedAt = session(src), referral = { code = profile(src).pin, redeemed = profile(src).referrals, referredBy = profile(src).referredBy },
            mailbox = profile(src).mailbox, isAdmin = isAdmin(src), giftCodes = isAdmin(src) and giftCodePayload() or {}
        })
    end)
end)

RegisterNetEvent('cyan_panel:server:refresh', function()
    local src = source
    TriggerClientEvent('cyan_panel:client:refreshData', src, { player = playerPayload(src), parties = partyPayload(), events = eventPayload(src), serverNow = os.time(), sessionStartedAt = session(src) })
end)

RegisterNetEvent('cyan_panel:server:joinEvent', function(eventId)
    local src = source
    for _, card in ipairs(eventPayload(src)) do
        if card.id == eventId then
            if card.joined then TriggerClientEvent('cyan_panel:client:toast', src, 'Already participating', 'info'); return end
            if card.status ~= 'open' or (card.endsAt and card.endsAt <= os.time()) then TriggerClientEvent('cyan_panel:client:toast', src, 'Event is not accepting players', 'error'); return end
            if card.players >= card.maxPlayers then TriggerClientEvent('cyan_panel:client:toast', src, 'Event is full', 'error'); return end
            local hook = Config.ServerJoinEvents[eventId]
            if not hook or hook == '' then TriggerClientEvent('cyan_panel:client:toast', src, 'Game integration is not configured', 'error'); return end
            TriggerEvent(hook, src, eventId)
            return
        end
    end
end)

RegisterNetEvent('cyan_panel:server:saveSetting', function(key, value)
    local src = source
    if type(key) ~= 'string' or Config.Settings[key] == nil or not Config.AvailableSettings[key] then return end
    local settings = getSettings(src)
    if type(Config.Settings[key]) == 'boolean' and type(value) ~= 'boolean' then return end
    if type(Config.Settings[key]) == 'number' then
        if type(value) ~= 'number' or value ~= value then return end
        value = key == 'hitVolume' and math.max(0, math.min(1,value)) or math.floor(math.max(0, math.min(23,value)))
    end
    settings[key] = value
    profile(src).settings = settings
    saveProfiles()
    TriggerClientEvent('cyan_panel:client:settings', src, settings)
end)

RegisterNetEvent('cyan_panel:server:createParty', function(name, private)
    local src = source
    name = tostring(name or ''):sub(1, 24)
    if name == '' then name = 'CYAN PARTY' end
    local existing = partyFor(src)
    if existing then TriggerClientEvent('cyan_panel:client:toast', src, 'You are already in a party', 'error'); return end
    local id = ('%s-%s'):format(os.time(), src)
    Parties[id] = { id = id, name = name, private = private == true, max = Config.Party.MaxMembers, owner = src, members = { src }, invite = ('%06d'):format(math.random(0,999999)) }
    TriggerClientEvent('cyan_panel:client:parties', -1, partyPayload())
    TriggerClientEvent('cyan_panel:client:toast', src, private and ('Private party PIN: ' .. Parties[id].invite) or 'Party created', 'success')
    if Config.Events.PartyCreate ~= '' then TriggerClientEvent(Config.Events.PartyCreate, src, Parties[id]) end
end)

RegisterNetEvent('cyan_panel:server:joinParty', function(id, invite)
    local src = source
    if partyFor(src) then TriggerClientEvent('cyan_panel:client:toast', src, 'Leave your current party first', 'error'); return end
    local p = Parties[tostring(id)]
    if not p then TriggerClientEvent('cyan_panel:client:toast', src, 'Party not found', 'error'); return end
    if #p.members >= p.max then TriggerClientEvent('cyan_panel:client:toast', src, 'Party is full', 'error'); return end
    if p.private and tostring(invite) ~= p.invite then TriggerClientEvent('cyan_panel:client:toast', src, 'This party is private', 'error'); return end
    p.members[#p.members+1] = src
    TriggerClientEvent('cyan_panel:client:parties', -1, partyPayload())
    TriggerClientEvent('cyan_panel:client:toast', src, 'Joined party', 'success')
    if Config.Events.PartyJoin ~= '' then TriggerClientEvent(Config.Events.PartyJoin, src, p) end
end)

RegisterNetEvent('cyan_panel:server:leaveParty', function()
    local src = source
    local id, p = partyFor(src)
    if not p then return end
    for i, member in ipairs(p.members) do if member == src then table.remove(p.members, i) break end end
    if #p.members == 0 then Parties[id] = nil
    elseif p.owner == src then p.owner = p.members[1] end
    TriggerClientEvent('cyan_panel:client:parties', -1, partyPayload())
    if Config.Events.PartyLeave ~= '' then TriggerClientEvent(Config.Events.PartyLeave, src, p) end
end)

RegisterNetEvent('cyan_panel:server:redeem', function(code)
    local src = source
    code = tostring(code or ''):upper():gsub('%s+', '')
    local c = Codes[code]
    if not c then TriggerClientEvent('cyan_panel:client:toast', src, 'Invalid gift code', 'error'); return end
    if c.enabled == false then TriggerClientEvent('cyan_panel:client:toast', src, 'This code is disabled', 'error'); return end
    if c.expiresAt and os.time() > c.expiresAt then TriggerClientEvent('cyan_panel:client:toast', src, 'This code has expired', 'error'); return end
    c.used = c.used or 0
    if c.maxUses and c.used >= c.maxUses then TriggerClientEvent('cyan_panel:client:toast', src, 'This code has reached its limit', 'error'); return end
    c.claimed = c.claimed or {}
    local pid = identifier(src)
    if c.claimed[pid] then TriggerClientEvent('cyan_panel:client:toast', src, 'You already redeemed this code', 'error'); return end
    if Framework == 'standalone' then TriggerClientEvent('cyan_panel:client:toast', src, 'Rewards require QB-Core or ESX', 'error'); return end
    c.progress = c.progress or {}
    local done = c.progress[pid] or 0
    for i = done + 1, #c.rewards do
        local r = c.rewards[i]
        local ok, granted = pcall(function()
            if r.type == 'item' then return rewardItem(src, r.name, r.amount, r.metadata)
            elseif r.type == 'money' then return rewardMoney(src, r.account, r.amount)
            elseif r.type == 'weapon' then return rewardWeapon(src, r.name, r.amount) end
            return false
        end)
        if not ok or not granted then TriggerClientEvent('cyan_panel:client:toast', src, 'Reward delivery failed. Check inventory and retry.', 'error'); return end
        c.progress[pid] = i
        saveCodes()
    end
    c.claimed[pid] = os.time()
    c.used = c.used + 1
    saveCodes()
    TriggerClientEvent('cyan_panel:client:toast', src, 'Gift code redeemed successfully', 'success')
end)

local function parseRewards(spec)
    local rewards = {}
    for token in tostring(spec or ''):gmatch('[^,]+') do
        local parts = {}
        for p in token:gmatch('[^:]+') do parts[#parts+1] = p end
        if parts[1] == 'item' and parts[2] then
            rewards[#rewards+1] = { type='item', name=parts[2], amount=tonumber(parts[3]) or 1 }
        elseif parts[1] == 'money' and parts[2] then
            rewards[#rewards+1] = { type='money', account=parts[2], amount=tonumber(parts[3]) or 0 }
        elseif parts[1] == 'weapon' and parts[2] then
            rewards[#rewards+1] = { type='weapon', name=parts[2], amount=tonumber(parts[3]) or 0 }
        end
    end
    return rewards
end

local function parseRewardSpec(spec)
    local rewards = {}
    for token in tostring(spec or ''):gmatch('[^,]+') do
        local parts = {}
        for part in token:gmatch('[^:]+') do parts[#parts+1] = part end
        local kind = (parts[1] or ''):lower()
        if kind == 'item' and parts[2] then
            rewards[#rewards+1] = { type = 'item', name = parts[2], amount = tonumber(parts[3]) or 1 }
        elseif kind == 'money' and parts[2] then
            rewards[#rewards+1] = { type = 'money', account = parts[2], amount = tonumber(parts[3]) or 0 }
        elseif kind == 'weapon' and parts[2] then
            rewards[#rewards+1] = { type = 'weapon', name = parts[2], amount = tonumber(parts[3]) or 0 }
        end
    end
    return rewards
end

giftCodePayload = function()
    local list = {}
    for code, c in pairs(Codes) do
        local rewards = c.rewards or {}
        local expiresText = nil
        if c.expiresAt then
            expiresText = os.date('%Y-%m-%d %H:%M', c.expiresAt)
        end
        list[#list+1] = {
            code = code,
            rewards = rewards,
            maxUses = c.maxUses,
            used = c.used or 0,
            enabled = c.enabled ~= false,
            expiresAt = c.expiresAt,
            expiresText = expiresText
        }
    end
    table.sort(list, function(a,b) return a.code < b.code end)
    return list
end

local function sendGiftCodes(src)
    if not isAdmin(src) then return end
    TriggerClientEvent('cyan_panel:client:giftCodes', src, giftCodePayload())
end

local function createGiftCode(src, code, rewardSpec, maxUses, hours)
    code = tostring(code or ''):upper():gsub('%s+', ''):sub(1, 32)
    local rewards = parseRewardSpec(rewardSpec)
    maxUses = math.floor(tonumber(maxUses) or Config.GiftCodeMaxUses)
    hours = tonumber(hours) or 0
    if not code:match('^[A-Z0-9_-]+$') then return false, 'Use letters, numbers, dash or underscore' end
    if Codes[code] then return false, 'Code already exists' end
    for _, r in ipairs(rewards) do if r.amount < 0 or r.amount ~= math.floor(r.amount) or r.amount > 100000000 or (r.type ~= 'weapon' and r.amount == 0) then return false, 'Invalid reward amount' end end
    if #rewards == 0 then return false, 'At least one valid reward is required' end
    if maxUses < 1 or maxUses > 1000000 then return false, 'Max uses must be 1-1000000' end
    Codes[code] = {
        rewards = rewards, maxUses = maxUses, used = 0, enabled = true,
        createdAt = os.time(), createdBy = src ~= 0 and playerName(src) or 'CONSOLE',
        expiresAt = hours > 0 and (os.time() + math.floor(hours * 3600)) or nil, claimed = {}
    }
    saveCodes()
    return true, code
end

RegisterNetEvent('cyan_panel:server:adminListCodes', function()
    local src = source
    if not isAdmin(src) then return end
    sendGiftCodes(src)
end)

RegisterNetEvent('cyan_panel:server:adminCreateCode', function(code, rewardSpec, maxUses, hours)
    local src = source
    if not isAdmin(src) then TriggerClientEvent('cyan_panel:client:toast', src, 'No permission', 'error'); return end
    local ok, result = createGiftCode(src, code, rewardSpec, maxUses, hours)
    if not ok then
        TriggerClientEvent('cyan_panel:client:toast', src, result, 'error')
        return
    end
    TriggerClientEvent('cyan_panel:client:toast', src, 'Gift code created: ' .. result, 'success')
    sendGiftCodes(src)
end)

RegisterNetEvent('cyan_panel:server:adminDeleteCode', function(code)
    local src = source
    if not isAdmin(src) then return end
    code = tostring(code or ''):upper():gsub('%s+', '')
    if not Codes[code] then TriggerClientEvent('cyan_panel:client:toast', src, 'Gift code not found', 'error'); return end
    Codes[code] = nil
    saveCodes()
    TriggerClientEvent('cyan_panel:client:toast', src, 'Gift code deleted', 'success')
    sendGiftCodes(src)
end)

RegisterNetEvent('cyan_panel:server:adminToggleCode', function(code, enabled)
    local src = source
    if not isAdmin(src) then return end
    code = tostring(code or ''):upper():gsub('%s+', '')
    if not Codes[code] then TriggerClientEvent('cyan_panel:client:toast', src, 'Gift code not found', 'error'); return end
    Codes[code].enabled = enabled == true
    saveCodes()
    TriggerClientEvent('cyan_panel:client:toast', src, Codes[code].enabled and 'Gift code enabled' or 'Gift code disabled', 'success')
    sendGiftCodes(src)
end)

RegisterCommand('giftcode', function(src, args)
    if not isAdmin(src) then if src ~= 0 then TriggerClientEvent('cyan_panel:client:toast', src, 'No permission', 'error') end return end
    local action = (args[1] or ''):lower()
    if action == 'create' then
        local ok, message = createGiftCode(src, args[2], args[3], args[4], args[5])
        print('[cyan_panel] ' .. tostring(message))
        if src ~= 0 then TriggerClientEvent('cyan_panel:client:toast', src, message, ok and 'success' or 'error') end
    elseif action == 'delete' then
        local code = (args[2] or ''):upper()
        Codes[code] = nil; saveCodes()
        if src ~= 0 then TriggerClientEvent('cyan_panel:client:toast', src, 'Gift code deleted', 'success') end
    elseif action == 'list' then
        print('--- CYAN PANEL GIFT CODES ---')
        for code, c in pairs(Codes) do print(code, ('%s/%s used'):format(c.used or 0, c.maxUses or '∞')) end
    elseif action == 'enable' or action == 'disable' then
        local code = (args[2] or ''):upper()
        if Codes[code] then Codes[code].enabled = action == 'enable'; saveCodes() end
    else
        print('Usage: /giftcode create CODE item:water:5,money:cash:1000 100 72')
        print('/giftcode delete CODE | list | enable CODE | disable CODE')
    end
end, false)

AddEventHandler('playerDropped', function()
    local src = source
    local id, p = partyFor(src)
    if p then
        for i, member in ipairs(p.members) do if member == src then table.remove(p.members, i) break end end
        if #p.members == 0 then Parties[id] = nil elseif p.owner == src then p.owner = p.members[1] end
    end
    PlayerState[src] = nil
    Sessions[src] = nil
    for _, event in pairs(EventState) do event.members[src] = nil end
    syncEvents()
    TriggerClientEvent('cyan_panel:client:parties', -1, partyPayload())
end)

CreateThread(function()
    loadCodes()
    print(('^2[%s]^7 loaded | framework: ^3%s^7'):format(RESOURCE, Framework))
end)
