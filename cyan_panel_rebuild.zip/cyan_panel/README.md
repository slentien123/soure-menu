# Cyan Panel 2.0 — hướng dẫn cài đặt

## Cài đặt
1. Sao lưu resource cũ và thư mục `data` trước khi thay file.
2. Chép thư mục `cyan_panel` vào resources, giữ nguyên data/codes.json và data/profiles.json đang dùng nếu nâng cấp.
3. Bật `ensure cyan_panel` sau qb-core / es_extended. Resource cũng mở được ở standalone nhưng không phát quà vật phẩm/tiền.
4. F10 hoặc /cyanpanel để mở, ESC để đóng. Cấu hình admin theo server.cfg.example.

## Nối trạng thái thật của airdrop / TDM / prop hunt (bắt buộc)
Bộ ZIP gốc chỉ có panel, không có resource chơi các mini-game. Bản này KHÔNG tự giả lập số người, lịch sự kiện hay báo JOIN thành công. Trước khi được nối, sự kiện hiện UNAVAILABLE, thời gian --:-- và không cho JOIN.

Trong resource game, gọi API SERVER sau khi mở/đóng sự kiện, khi người chơi đã được nhận vào, rời khu, chết nếu luật game loại người chết, hoặc chuyển bucket:

```lua
exports.cyan_panel:SetEventState('airdrop', {
    status = 'open', -- open / running / ended / unavailable
    endsAt = os.time() + 300, -- deadline Unix seconds của phase hiện tại
    players = {12, 34, 56} -- danh sách server ID thực, không phải tổng người online
})
```
Giữ nguyên `endsAt` trong các lần cập nhật roster, không cộng lại 300 mỗi lần. `open` cho phép xin vào; `running` khóa người mới; khi deadline hết UI chuyển ended ở lần đồng bộ kế tiếp. Thay id bằng `tdm` hoặc `prop` cho các game khác. API loại trùng ID và người đã ngắt kết nối. Panel cập nhật 3 giây/lần; đồng hồ chạy cục bộ theo mốc server giữa các lần đồng bộ.

Trong `Config.ServerJoinEvents`, điền local server event mà game của bạn xử lý. Ví dụ:
```lua
Config.ServerJoinEvents.airdrop = 'my_airdrop:panelJoin'
```
Trong resource airdrop của bạn:
```lua
AddEventHandler('my_airdrop:panelJoin', function(src, eventId)
    -- Kiểm tra điều kiện và capacity trong game, thêm src vào roster thật,
    -- teleport/bucket theo game, sau đó gọi SetEventState với roster mới.
    -- Không RegisterNetEvent cho hook này; game vẫn phải tự kiểm tra quyền vào.
end)
```
Không dùng event client để xác nhận người tham gia. Resource game phải cập nhật UNAVAILABLE khi dừng; sau restart cyan_panel cần đẩy lại snapshot.

## Đồng hồ online
Tính từ playerJoining ở server và không reset khi đóng/mở panel. Reconnect bắt đầu phiên mới. Nếu restart cyan_panel khi người chơi đã online, chỉ tính được từ lúc resource khởi động vì không có dữ liệu phiên trước đó.

## Các tab
- HOME: dữ liệu framework, sự kiện thật qua API.
- PIN: mã bền vững theo nhân vật/license; mỗi người liên kết một PIN, chống tự nhập. Lưu số người giới thiệu. Chưa phát thưởng referral tự động.
- MAILBOX: hộp thư lưu JSON, đánh dấu tất cả đã đọc. Resource khác gửi thư bằng `exports.cyan_panel:SendMail(src, title, message)`.
- PARTY: tạo public/private, private có PIN hiện khi tạo, nhập PIN khi JOIN; rời party, chuyển chủ khi chủ rời và dọn thành viên disconnect. Party là nhóm của panel; gameplay party bên ngoài nối qua Config.Events.
- REDEEM / GIFT ADMIN: tạo, xem, bật/tắt, xóa mã; chỉ admin tạo mã. Kiểm tra số lượng thưởng và không ghi đè mã tồn tại. Lưu tiến độ từng phần thưởng để thử lại khi kho đồ từ chối. Cần kiểm thử inventory thực; không có giao dịch nguyên tử giữa inventory và JSON nếu server crash đúng lúc phát thưởng.
- SETTING: hint, âm click, volume, đóng băng giờ và chọn giờ có xử lý thực. Các tùy chọn gameplay không có resource xử lý được ẩn. Khi tích hợp, bật key trong Config.AvailableSettings và xử lý local client event `cyan_panel:settingsChanged`. Có thể xung đột nếu resource weather/time khác liên tục override đồng hồ.

Stats tùy chỉnh từ SERVER:
```lua
exports.cyan_panel:SetPlayerStats(src, {kills=19, deaths=79, accuracy=0.24, mmr=0, rank='UNRANK'})
```

## Giao diện và kiểm tra
Bố cục theo ảnh 1520×855: ba thẻ sự kiện trên, đồng hồ góc phải, panel giữa, sáu tab thường và tab admin khi có quyền, profile và ba banner cyan. Không kèm nền GTA, logo server, ảnh mèo hoặc artwork banner gốc vì ZIP không chứa các asset đó; không phải bản khớp ảnh 100%.
Đã kiểm tra cú pháp Lua 5.4 và JavaScript. Chưa chạy FiveM/QB/ESX hoặc kiểm tra hình bằng trình duyệt (môi trường không có Chromium).

Trước khi đưa lên server chính: thử 2 người cùng vào/rời air drop, giới hạn slot, reconnect, đóng/mở panel, hết deadline, PIN trùng, party private, inventory đầy, quyền admin và restart resource. Không thay dữ liệu đang sử dụng bằng JSON rỗng trong ZIP.
